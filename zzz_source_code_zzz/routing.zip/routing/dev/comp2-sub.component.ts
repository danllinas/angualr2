import {Component} from 'angular2/core';

@Component({
    selector: 'comp1-sub',
    template: `
        This is component 1 subroute
    `,
})
export class Comp1SubComponent {
}