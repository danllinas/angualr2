import {Component} from 'angular2/core';

@Component({
    selector: 'comp1-main',
    template: `
        This is component 1 main
    `,
})
export class Comp1MainComponent {
}