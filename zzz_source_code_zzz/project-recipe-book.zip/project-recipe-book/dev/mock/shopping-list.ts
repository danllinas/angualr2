import {Ingredient} from "../shared/ingredient";

export let SHOPPING_LIST: Ingredient[] = [];