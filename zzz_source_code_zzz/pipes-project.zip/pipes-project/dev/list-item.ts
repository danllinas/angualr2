export interface ListItem {
    name: string;
    amount: number;
}