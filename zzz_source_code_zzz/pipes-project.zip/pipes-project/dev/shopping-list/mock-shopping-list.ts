import {ListItem} from "../list-item";
export let shopping_list: Array<ListItem> = new Array();