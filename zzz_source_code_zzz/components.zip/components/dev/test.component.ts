import {Component} from 'angular2/core';

@Component({
    selector: 'test',
    templateUrl: 'templates/test.tpl.html'
})
export class TestComponent {

}